#!/bin/sh
DATE=$(date "+%d-%m-%Y")
DIR=$PWD/backup-ide-$DATE
mkdir $DIR
for i in `oc get projects --no-headers |grep Active |awk '{print $1}'`
do
  oc project $i
  for j in pvc
  do
    echo  -e  "\nnamespace,$i,cn1\n"  >>  $DIR/identificadores.csv
    #echo  -e  "\nNAME,VOLUME,ACCESS\n"  >>  $DIR/identificadores.csv 
    for k in `oc get $j -n $i --no-headers |awk '{print $1}'`
    do
    oc get pvc/$k -o wide |  awk '{ print $1,$3,$5 }' | awk '{if (NR!=1) {print}}' >>  $DIR/identificadores.csv	
    done
  done
done
cd $DIR
mv identificadores.csv identificadores.txt && sed -i 's/ /,/g' identificadores.txt  && mv identificadores.txt identificadores.csv 
