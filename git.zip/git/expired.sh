#!/bin/bash
DIR=$PWD/expire
DIR=$DIR
mkdir -p $DIR
cd $DIR
for i in `oc get projects --no-headers |grep Active |awk '{print $1}'`
do
oc project $i
  for j in routes 
  do
    for k in `oc get $j -n $i --no-headers |awk '{print $1}'`
    do
    routes=$(oc get routes $k -o yaml | grep host | awk 'END{print}' | awk '{print $2}' )
    expires=$(curl -Ivk --silent  https://$routes 2>&1 | grep expire)
    echo "https://$routes ; namespace $i ;  $expires " >> expire-certificados-pro.txt
    done
  done
done

